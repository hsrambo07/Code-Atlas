export const utils = { add: (a, b) => a + b };
