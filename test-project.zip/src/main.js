function hello() { console.log("Hello World"); }
